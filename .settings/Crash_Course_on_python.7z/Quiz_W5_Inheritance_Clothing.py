'''
Created on Jul 6, 2020

@author: uid96630
'''
# *****************************************************************************************************
# Lets create a new class together and inherit from it. Below we have a base class called Clothing. 
# Together, lets create a second class, called Shirt, that inherits methods from the Clothing class. 
# Fill in the blanks to make it work properly.
# ******************************************************************************************************
class Clothing:
    material = ""
    def __init__(self,name):
        self.name = name
    def checkmaterial(self):
        print("This {} is made of {}".format(self.name,self.material))
            
class Shirt(Clothing):
    material="Cotton"

polo = Shirt("Polo")
polo.checkmaterial()